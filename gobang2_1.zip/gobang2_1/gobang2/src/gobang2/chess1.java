package gobang2;

public class chess1 implements Comparable<chess1>{

	private int x,y;
	private int player;
	private int orderNum;
	
	private int sum;
	private int offense;
	private int defense;
	
	private StringBuffer buff = new StringBuffer();
	public chess1(int x,int y,int player,int OrderNum)
	{
		this.x =x;
		this.y = y;
		this.player = player;
		this.orderNum = OrderNum;
	}
	public StringBuffer getBuff() {
		return buff;
	}
	public void setBuff(StringBuffer buff) {
		this.buff = buff;
	}
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	public int getOffense() {
		return offense;
	}
	public void setOffense(int offense) {
		this.offense = offense;
	}
	public int getDefense() {
		return defense;
	}
	public void setDefense(int defense) {
		this.defense = defense;
	}
	public int getX() {
		return x;
	}
	public int getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getPlayer() {
		return player;
	}
	public void setPlayer(int player) {
		this.player = player;
	}
	public boolean isEMPTY()
	{
		return this.player == gobangpanel.EMPTY;
	}
	@Override
	public int compareTo(chess1 o) {
		// TODO Auto-generated method stub
		
		if(this.sum>o.sum)
		{
			return -1;
		}
		else if(this.sum<o.sum)
		{
			return 1;
		}
		return 0;
	}
	@Override
	public String toString() {
		return "chess1 [x=" + x + ", y=" + y + ", player=" + player + ", orderNum=" + orderNum + ", sum=" + sum
				+ ", offense=" + offense + ", defense=" + defense + "]";
	}
	
	
}
