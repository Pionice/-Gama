package gobang2;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;
import javax.swing.border.TitledBorder;

public class gobangFrame extends JFrame{
	gobangpanel PPanel = new gobangpanel();
	JCheckBox order = new JCheckBox("显示下棋顺序");
	JButton huiqi = new JButton("悔棋");
	JButton NewGame = new JButton("新游戏");
	JRadioButton renren = new JRadioButton("人人");
	JRadioButton renji = new JRadioButton("人机");
	
	JRadioButton jiandan = new JRadioButton("简单");
	JRadioButton kunnan = new JRadioButton("困难");
	JRadioButton diyu = new JRadioButton("地狱");
	
	JRadioButton yes = new JRadioButton("是");
	JRadioButton wrong = new JRadioButton("否");
	JComboBox depth = new JComboBox<Integer>(new Integer[] {1,3,5,});
	JComboBox nodeCount = new JComboBox<Integer>(new Integer[] {3,5,10});
	
	JButton  tishi = new JButton("提示");
	boolean tishi1 = false;
	TextArea area = new TextArea();
	public void star()
	{
		this.add(PPanel, BorderLayout.WEST); //将棋盘添加至窗口西侧
		
		//添加右侧功能区
		JPanel rightPanel = new JPanel();
		rightPanel.setLayout(new BoxLayout(rightPanel,BoxLayout.Y_AXIS));
		
		//多行文本框
		//JPanel panel1 = new JPanel(new BorderLayout());
		//border显示标题
		//panel1.setBorder(new TitledBorder("在棋盘上单击鼠标右键，查看各点估值"));
		
		//ImageIcon image=new ImageIcon("‎⁨/src/gobang2/综测加分证明2.jpg⁩");
		JLabel label=new JLabel(new ImageIcon("img/444.png"));//用图片构造一个JLabel标签
		//label.setIcon(new ImageIcon("/Users/admin/Desktop/综测加分证明2.jpg⁩") );
		//panel1.add(label);//再把标签加到容器上就好了
		
		//area.setEditable(false);
		//panel1.add(area);
		//rightPanel.add(panel1);
		rightPanel.add(label);
		//模式
		JPanel panel2 = new JPanel();
		panel2.setBorder(new TitledBorder("模式"));	
		ButtonGroup group1 = new ButtonGroup();
		
		renji.setSelected(true);
		group1.add(renren);
		group1.add(renji);
		
		panel2.add(renji);
		panel2.add(renren);
		rightPanel.add(panel2);
		
		
		JPanel panel3 = new JPanel();
		panel3.setBorder(new TitledBorder("是否先手"));
		
		
		ButtonGroup group2= new ButtonGroup();
		group2.add(yes);
		group2.add(wrong);
		
		panel3.add(yes);
		panel3.add(wrong);
		rightPanel.add(panel3);
		//搜索树
		JPanel panel4 = new JPanel();
		panel4.setBorder(new TitledBorder("游戏难度"));
		
		ButtonGroup group3= new ButtonGroup();
		group3.add(jiandan);
		group3.add(kunnan);
		group3.add(diyu);
		
		panel4.add(jiandan);
		panel4.add(kunnan);
		panel4.add(diyu);
		
		
		
		//panel4.add(new JLabel("搜索深度"));
		
		//panel4.add(depth);
		//panel4.add(new JLabel("节点"));
		//panel4.add(nodeCount);
		
		rightPanel.add(panel4);
		//新游戏按钮
		JPanel panel6 = new JPanel();
		panel6.add(NewGame);
		panel6.add(tishi);
		rightPanel.add(panel6);
		
		//rightPanel.add(NewGame);
		//rightPanel.add(tishi);
		NewGame.addMouseListener(mouseListener3);
		tishi.addMouseListener(mouseListener4);
		//其他
		JPanel panel5 = new JPanel();
		panel5.setBorder(new TitledBorder("其他"));
		
		order.addMouseListener(mouseListener2);
		panel5.add(order);
		
		//悔棋按钮
		huiqi.addMouseListener(mouseListener1);
		panel5.add(huiqi);
		
		rightPanel.add(panel5);
		
		
		
		this.add(rightPanel);
		this.setTitle("五子棋");
		this.setResizable(false);
		this.setSize(900, 700);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//如果不加这句话关闭窗口后程序并未完全退出，会继续占用内存
	}

	private MouseListener mouseListener1 = new MouseAdapter() //悔棋响应消息
	{
		@Override
		public void mouseClicked(MouseEvent e) 
		{
			PPanel.huiqi();
		}
	};
	private MouseListener mouseListener2 = new MouseAdapter()//显示下棋顺序
	{
		@Override
		public void mouseClicked(MouseEvent e) 
		{
			PPanel.showOrder(order.isSelected());
		}
	};
	private MouseListener mouseListener3 = new MouseAdapter()//开始新游戏
	{
		@Override
		public void mouseClicked(MouseEvent e) 
		{
			boolean mode = renren.isSelected()?true:false;
			//boolean intel = renji.isSelected()?true:false;
			boolean xianshou = yes.isSelected()?true:false;
			
			int depthTmp = 0;
			int nodeCountTmp = 0;
			if (jiandan.isSelected())
			{
				depthTmp = 1;
				nodeCountTmp = 3;
			}
			else if(kunnan.isSelected())
			{
				depthTmp = 3;
				nodeCountTmp = 5;
			}
			else if(diyu.isSelected())
			{
				depthTmp = 5;
				nodeCountTmp = 10;
			}
			
			
			
			PPanel.newGame(mode,true,depthTmp,nodeCountTmp,area,xianshou);
			
			
		}

		
	};
	private MouseListener mouseListener4 = new MouseAdapter()
		{
			public void mouseClicked(MouseEvent e) 
			{
				tishi1 = true;
				PPanel.yesornotishi(tishi1);
			}
		
		
		};
}