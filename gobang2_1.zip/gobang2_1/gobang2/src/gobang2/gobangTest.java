package gobang2;

public class gobangTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		gobangFrame fame = new gobangFrame();
		fame.star();
		

	}

}
